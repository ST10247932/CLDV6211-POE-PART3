﻿using Microsoft.AspNetCore.Mvc;

namespace KhumaloCraftWebsite.Controllers
{
    public class MyWorkController : Controller
    {
        public IActionResult Index()
        {
            return View("~/Views/Home/Index.cshtml");
        }
        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult KumWork()
        {
            return View("~/Views/Home/KumWork.cshtml");
        }

    }
}
